
package com.lazzy.manager;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {

    private LinearLayout root, content;
    private EditText luaEditor;

    private final int BG = Color.rgb(17, 19, 24);
    private final int PANEL = Color.rgb(29, 32, 40);
    private final int BLUE = Color.rgb(100, 170, 255);

    private static final int PICK_FOLDER = 100;
    private static final int PICK_DOWNLOAD = 101;
    private static final int SAVE_LUA = 102;
    private static final int PICK_APK = 103;
    private static final int OPEN_LUA = 104;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        home();
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(Color.WHITE);
        t.setPadding(16, 14, 16, 14);
        return t;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 18, 16, 12);
        root.setBackgroundColor(BG);
        setContentView(root);

        TextView heading = text(title, 26);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll,
            new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void button(String title, String subtitle,
                        Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(8, 6, 8, 6);
        card.setBackgroundColor(PANEL);
        card.setClickable(true);
        card.setFocusable(true);

        TextView name = text(title, 18);
        name.setTypeface(null, Typeface.BOLD);
        card.addView(name);
        card.addView(text(subtitle, 13));

        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 7, 0, 7);
        content.addView(card, params);
        card.setOnClickListener(v -> action.run());
    }

    private void toast(String message) {
        Toast.makeText(this, message,
            Toast.LENGTH_SHORT).show();
    }

    private void home() {
        base("LAZZY MANAGER");
        content.addView(text("Your files. Your tools.", 14));

        button("📁 File Manager",
            "Browse files and choose storage folders",
            this::fileManager);
        button("💻 Lua Studio",
            "Create, open and save Lua scripts",
            this::luaStudio);
        button("📦 APK Download",
            "Browse APK files and trusted sources",
            this::apkDownload);
        button("🔐 File Access",
            "Choose an accessible storage folder",
            this::chooseFolder);
    }

    private void chooseFolder() {
        Intent i = new Intent(
            Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(i, PICK_FOLDER);
    }

    private void fileManager() {
        base("File Manager");
        button("📂 Choose storage folder",
            "Browse an accessible folder", this::chooseFolder);
        button("⬇️ Open a downloaded file",
            "Choose a file from your device",
            () -> pickDocument(PICK_DOWNLOAD, "*/*"));
        button("📄 Open Lua script",
            "Choose an existing Lua or text file",
            () -> pickDocument(OPEN_LUA, "*/*"));
        button("🤖 Android / OBB",
            "Choose a folder if Android permits access",
            this::chooseFolder);
        button("← Home", "Return to main screen", this::home);
    }

    private void luaStudio() {
        base("Lua Studio");

        luaEditor = new EditText(this);
        luaEditor.setTextColor(Color.WHITE);
        luaEditor.setHintTextColor(Color.GRAY);
        luaEditor.setHint("-- Write Lua code here");
        luaEditor.setGravity(Gravity.TOP | Gravity.START);
        luaEditor.setTypeface(Typeface.MONOSPACE);
        luaEditor.setTextSize(14);
        luaEditor.setMinLines(12);
        luaEditor.setPadding(12, 12, 12, 12);
        luaEditor.setBackgroundColor(PANEL);

        content.addView(luaEditor,
            new LinearLayout.LayoutParams(-1, 400));

        button("📂 Open Lua file",
            "Load a text or Lua file into the editor",
            () -> pickDocument(OPEN_LUA, "*/*"));
        button("💾 Save Lua file",
            "Write the editor contents to a file",
            this::saveLua);
        button("← Home", "Return to main screen", this::home);
    }

    private void saveLua() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "main.lua");
        startActivityForResult(i, SAVE_LUA);
    }

    private void apkDownload() {
        base("APK Download");
        button("📦 Browse downloaded APKs",
            "Choose an APK already on your phone",
            () -> pickDocument(PICK_APK,
                "application/vnd.android.package-archive"));
        button("🌐 APKMirror", "Browse APK listings",
            () -> openUrl("https://www.apkmirror.com/"));
        button("🌐 F-Droid", "Browse open-source Android apps",
            () -> openUrl("https://f-droid.org/"));
        button("← Home", "Return to main screen", this::home);
    }

    private void pickDocument(int request, String mime) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        startActivityForResult(i, request);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(
                Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Cannot open link");
        }
    }

    @Override
    protected void onActivityResult(
        int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK ||
            data == null || data.getData() == null) {
            return;
        }

        Uri uri = data.getData();

        if (requestCode == PICK_FOLDER) {
            getContentResolver().takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            toast("Folder access granted where supported");
        } else if (requestCode == SAVE_LUA) {
            writeLua(uri);
        } else if (requestCode == OPEN_LUA) {
            readLua(uri);
        } else if (requestCode == PICK_DOWNLOAD) {
            toast("Selected: " + uri.getLastPathSegment());
        } else if (requestCode == PICK_APK) {
            toast("Selected APK: " + uri.getLastPathSegment());
        }
    }

    private void writeLua(Uri uri) {
        if (luaEditor == null) {
            toast("Open Lua Studio first");
            return;
        }

        try (OutputStream out =
                 getContentResolver().openOutputStream(uri)) {
            if (out == null) {
                toast("Could not open destination");
                return;
            }
            out.write(luaEditor.getText().toString()
                .getBytes("UTF-8"));
            out.flush();
            toast("Lua file saved successfully");
        } catch (IOException e) {
            toast("Save failed: " + e.getMessage());
        }
    }

    private void readLua(Uri uri) {
        try (java.io.InputStream in =
                 getContentResolver().openInputStream(uri)) {
            if (in == null) {
                toast("Could not open file");
                return;
            }

            java.io.ByteArrayOutputStream buffer =
                new java.io.ByteArrayOutputStream();
            byte[] bytes = new byte[4096];
            int count;

            while ((count = in.read(bytes)) != -1) {
                buffer.write(bytes, 0, count);
            }

            luaStudio();
            luaEditor.setText(
                new String(buffer.toByteArray(), "UTF-8"));
        } catch (IOException e) {
            toast("Could not read file");
        }
    }
}

package com.lazzy.manager

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import java.io.IOException

class MainActivity : ComponentActivity() {
    private val cyan = Color.rgb(22, 217, 245)
    private val bg = Color.rgb(5, 11, 18)
    private val panelBg = Color.rgb(10, 20, 31)
    private val textColor = Color.WHITE

    private data class Pane(
        var root: DocumentFile? = null,
        var current: DocumentFile? = null,
        var selected: DocumentFile? = null,
        var label: String = "Choose folder"
    )

    private val left = Pane()
    private val right = Pane()
    private var activeLeft = true
    private lateinit var leftList: LinearLayout
    private lateinit var rightList: LinearLayout
    private lateinit var status: TextView
    private lateinit var leftPath: TextView
    private lateinit var rightPath: TextView

    private val chooseLeft = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) acceptFolder(uri, left)
    }
    private val chooseRight = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) acceptFolder(uri, right)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restorePane(left, "left_uri")
        restorePane(right, "right_uri")
        refreshAll()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(10))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.bookshelf_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Lazzy Manager bookshelf logo"
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)))
        val title = TextView(this).apply {
            text = "LAZZY MANAGER\\nDual-panel file manager • V2.0"
            textSize = 18f; setTextColor(cyan); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        outer.addView(header)
        status = TextView(this).apply {
            text = "Choose a folder for each panel. Access is remembered by Android."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        outer.addView(status)

        val chooserRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chooserRow.addView(actionButton("LEFT: Choose folder") { chooseLeft.launch(null) }, weight())
        chooserRow.addView(actionButton("RIGHT: Choose folder") { chooseRight.launch(null) }, weight())
        outer.addView(chooserRow)

        val panes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val leftBox = paneContainer(true)
        val rightBox = paneContainer(false)
        panes.addView(leftBox, LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = dp(4) })
        panes.addView(rightBox, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = dp(4) })
        outer.addView(panes)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("Copy →") { transfer(false) }, weight())
        actions.addView(actionButton("Move →") { transfer(true) }, weight())
        actions.addView(actionButton("Rename") { renameSelected() }, weight())
        actions.addView(actionButton("Delete") { deleteSelected() }, weight())
        outer.addView(actions)
        val more = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        more.addView(actionButton("New folder") { newFolder() }, weight())
        more.addView(actionButton("Swap panels") {
            val a = left.root; val ac = left.current; val al = left.label
            left.root = right.root; left.current = right.current; left.label = right.label
            right.root = a; right.current = ac; right.label = al
            left.selected = null; right.selected = null
            refreshAll()
        }, weight())
        more.addView(actionButton("Refresh") { refreshAll() }, weight())
        outer.addView(more)
        setContentView(outer)
    }

    private fun paneContainer(isLeft: Boolean): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panelBg)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val path = TextView(this).apply {
            text = if (isLeft) "LEFT PANEL" else "RIGHT PANEL"
            textSize = 13f; setTextColor(cyan); setPadding(dp(4), dp(6), dp(4), dp(6))
            setOnClickListener { activeLeft = isLeft; updateStatus("Active panel: ${if (isLeft) "left" else "right"}") }
        }
        if (isLeft) leftPath = path else rightPath = path
        box.addView(path)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (isLeft) leftList = list else rightList = list
        box.setOnClickListener { activeLeft = isLeft }
        return box
    }

    private fun acceptFolder(uri: Uri, pane: Pane) {
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) { }
        val doc = DocumentFile.fromTreeUri(this, uri)
        if (doc == null || !doc.canRead()) {
            updateStatus("Android did not grant access to that folder.")
            return
        }
        pane.root = doc; pane.current = doc; pane.selected = null
        pane.label = doc.name ?: "Selected folder"
        getPreferences(MODE_PRIVATE).edit().putString(if (pane === left) "left_uri" else "right_uri", uri.toString()).apply()
        refreshAll()
        updateStatus("Folder access saved. You normally won't need to pick it again.")
    }

    private fun restorePane(pane: Pane, key: String) {
        val raw = getPreferences(MODE_PRIVATE).getString(key, null) ?: return
        try {
            val uri = Uri.parse(raw)
            val doc = DocumentFile.fromTreeUri(this, uri)
            if (doc != null && doc.canRead()) {
                pane.root = doc; pane.current = doc; pane.label = doc.name ?: "Selected folder"
            }
        } catch (_: Exception) { }
    }

    private fun refreshAll() {
        renderPane(left, leftList, leftPath, true)
        renderPane(right, rightList, rightPath, false)
    }

    private fun renderPane(pane: Pane, list: LinearLayout, path: TextView, isLeft: Boolean) {
        list.removeAllViews()
        val current = pane.current
        path.text = (if (isLeft) "LEFT • " else "RIGHT • ") + (current?.name ?: "No folder")
        if (current == null) {
            addRow(list, "Tap “Choose folder” to grant access", false) {}
            return
        }
        if (current.uri != pane.root?.uri) {
            addRow(list, "⬆  ..  (Parent folder)", false) {
                pane.current = current.parentFile ?: pane.root
                pane.selected = null; refreshAll()
            }
        }
        val children = try { current.listFiles().sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { it.name?.lowercase() ?: "" }) }
        catch (_: Exception) { emptyList() }
        if (children.isEmpty()) addRow(list, "This folder is empty", false) {}
        children.forEach { file ->
            val selected = pane.selected?.uri == file.uri
            val prefix = if (file.isDirectory) "📁 " else "📄 "
            val row = TextView(this).apply {
                text = (if (selected) "✓ " else "") + prefix + (file.name ?: "Unnamed")
                textSize = 13f
                setTextColor(if (selected) cyan else textColor)
                setPadding(dp(6), dp(11), dp(4), dp(11))
                setBackgroundColor(if (selected) Color.rgb(18, 48, 62) else panelBg)
            }
            row.setOnClickListener {
                activeLeft = isLeft
                if (file.isDirectory) { pane.current = file; pane.selected = null; refreshAll() }
                else { pane.selected = file; refreshAll() }
            }
            row.setOnLongClickListener { activeLeft = isLeft; pane.selected = file; refreshAll(); true }
            list.addView(row)
            val divider = View(this).apply { setBackgroundColor(Color.rgb(35, 55, 68)) }
            list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun selectedPane() = if (activeLeft) left else right
    private fun destinationPane() = if (activeLeft) right else left

    private fun transfer(move: Boolean) {
        val sourcePane = selectedPane()
        val targetPane = destinationPane()
        val source = sourcePane.selected
        val target = targetPane.current
        if (source == null || target == null) { updateStatus("Select a file or folder, then choose a destination folder in the other panel."); return }
        if (source.uri == target.uri || isInside(source, target)) { updateStatus("Can't copy a folder into itself."); return }
        try {
            copyDocument(source, target)
            if (move) source.delete()
            sourcePane.selected = null
            refreshAll()
            updateStatus(if (move) "Move completed." else "Copy completed.")
        } catch (e: Exception) { updateStatus("Operation failed: ${e.message ?: "permission or storage error"}") }
    }

    private fun isInside(source: DocumentFile, target: DocumentFile): Boolean {
        var p: DocumentFile? = target
        while (p != null) {
            if (p.uri == source.uri) return true
            p = p.parentFile
        }
        return false
    }

    private fun copyDocument(source: DocumentFile, destination: DocumentFile) {
        val name = source.name ?: "Copied item"
        if (source.isDirectory) {
            val newDir = destination.createDirectory(uniqueName(destination, name))
                ?: throw IOException("Cannot create destination folder")
            source.listFiles().forEach { copyDocument(it, newDir) }
        } else {
            val mime = source.type ?: "application/octet-stream"
            val out = destination.createFile(mime, uniqueName(destination, name))
                ?: throw IOException("Cannot create destination file")
            contentResolver.openInputStream(source.uri).use { input ->
                contentResolver.openOutputStream(out.uri).use { output ->
                    if (input == null || output == null) throw IOException("Cannot open file stream")
                    input.copyTo(output)
                }
            }
        }
    }

    private fun uniqueName(folder: DocumentFile, original: String): String {
        if (folder.findFile(original) == null) return original
        val dot = original.lastIndexOf('.')
        val base = if (dot > 0) original.substring(0, dot) else original
        val ext = if (dot > 0) original.substring(dot) else ""
        var i = 1
        while (folder.findFile("$base ($i)$ext") != null) i++
        return "$base ($i)$ext"
    }

    private fun renameSelected() {
        val pane = selectedPane(); val file = pane.selected ?: return updateStatus("Select an item first.")
        val input = EditText(this).apply { setText(file.name ?: ""); setTextColor(textColor) }
        android.app.AlertDialog.Builder(this).setTitle("Rename").setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Rename") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && file.renameTo(name)) { pane.selected = null; refreshAll(); updateStatus("Renamed.") }
                else updateStatus("Rename failed.")
            }.show()
    }

    private fun deleteSelected() {
        val pane = selectedPane(); val file = pane.selected ?: return updateStatus("Select an item first.")
        android.app.AlertDialog.Builder(this).setTitle("Delete ${file.name}?")
            .setMessage("This removes the selected item from its folder.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                if (file.delete()) { pane.selected = null; refreshAll(); updateStatus("Deleted.") }
                else updateStatus("Delete failed. Android may restrict this location.")
            }.show()
    }

    private fun newFolder() {
        val pane = selectedPane(); val folder = pane.current ?: return updateStatus("Choose a folder first.")
        val input = EditText(this).apply { hint = "Folder name"; setTextColor(textColor) }
        android.app.AlertDialog.Builder(this).setTitle("New folder").setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && folder.createDirectory(name) != null) { refreshAll(); updateStatus("Folder created.") }
                else updateStatus("Couldn't create folder.")
            }.show()
    }

    private fun addRow(parent: LinearLayout, label: String, selected: Boolean, click: () -> Unit) {
        val t = TextView(this).apply {
            text = label; textSize = 13f; setTextColor(if (selected) cyan else Color.LTGRAY)
            setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { click() }
        }
        parent.addView(t)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false; setTextColor(cyan)
            setBackgroundColor(Color.rgb(12, 27, 39)); setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) }
        }

    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun updateStatus(message: String) { status.text = message }
}
